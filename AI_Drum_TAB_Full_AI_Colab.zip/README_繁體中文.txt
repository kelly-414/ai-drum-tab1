AI Drum TAB — 完整歌曲 AI 鼓譜辨識（iPhone + Google Colab）
===========================================================

這份專案不是先前的手動格子編輯器，而是雲端 AI 轉錄工作流程。

使用：
1. iPhone Safari 開啟 https://colab.research.google.com/
2. 登入 Google 帳號。
3. 在 Colab 選「上傳筆記本」，選擇 ZIP 解壓後的 AI_Drum_TAB_Full_AI.ipynb。
4. 依序執行每個區塊。安裝區塊會安裝 dettato / FFmpeg。
5. 上傳歌曲時，從 iPhone「檔案」選取 M4A。
6. 等待模型下載與整首歌辨識完成。
7. 最後下載 PDF、MIDI、JSON。

重要：
- 使用開源 dettato 多階段 AI 音訊轉錄模型。模型權重首次會由 Hugging Face 下載。
- Google Colab 免費 GPU/CPU 會依 Google 當時資源、帳號與使用量決定，不能保證免費無限或每次都提供 GPU。
- 這份 Notebook 尚未在本次執行環境連網安裝模型並跑完使用者音檔，因此不宣稱已通過實際辨識測試。
- AI 可能漏音、誤判或把其他打擊聲辨識成鼓；PDF 是自動生成的初稿，請校對。
- PDF 為簡化標準五線鼓譜呈現；MIDI 是可編輯的主要機器輸出。
